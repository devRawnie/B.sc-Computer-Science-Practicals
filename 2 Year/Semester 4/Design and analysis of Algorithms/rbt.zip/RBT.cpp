#include "../HeaderFiles/RBT.h"

int main(){
	char choice;
	RedBlackTree rbt;
	do{
		cout<<"1. Insert\n2. Delete\n3. Display\n4. Check color of a node\n\nEnter choice : ";
		int ch;
		cin>>ch;
		int n;
		switch(ch){
			case 1:
				cout<<"\nEnter element : ";
				cin>>n;
				rbt.insert(n);
				break;
			case 2:
				cout<<"\nEnter value to delete : ";
				cin>>n;
				rbt.del(n);
				break;
			case 3:
				rbt.print();
				cout<<endl;
				break;
			case 4:
				cout<<"Enter the node value : ";
				cin>>n;
				cout<<rbt.getColor(n);
				break;
			default:
				cout<<"Wrong Choice";
				break;
		}
		cout<<"\nDo you want to continue? (Y/N) - ";
		cin>>choice;
	}while(choice=='y'||choice=='Y');
}
